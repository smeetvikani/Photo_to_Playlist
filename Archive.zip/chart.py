import boto3
import datetime
import urllib
from pymongo import MongoClient
from PIL import Image, ImageFilter
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import scipy

def logg_import(url,artist = 'beyonce knowles',is_uploaded_file=False):
    aws_access_key_id='AKIAIER77XWYHTNMKAPA'
    aws_secret_access_key= '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'

    s3 = boto3.resource(
        's3',
        region_name='us-east-2',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )
    photo_title=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")+'.jpg'
    print(photo_title)
    if is_uploaded_file:
        output = open(f"images/{photo_title}","wb")
        output.write(url.read())
        output.close()
    else:
        resource = urllib.request.urlopen(url)
        output = open(f"images/{photo_title}","wb")
        output.write(resource.read())
        output.close()
    data = open(f'images/{photo_title}', 'rb')
    s3.Bucket('facialanalysistest').put_object(Key=f'{photo_title}', Body=data, ACL='public-read')
    photo=photo_title
    bucket='facialanalysistest'
    client=boto3.client('rekognition', region_name='us-east-2',    aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,)
    response = client.detect_faces(Image={'S3Object':{'Bucket':bucket,'Name':photo}},Attributes=['ALL'])
    face_details_imported=response

    print(f'number of people: {len(response["FaceDetails"])}')  #number of peopple.
    print(response['FaceDetails'][0]['Emotions'])


    # In[29]:


    client = MongoClient()
    db = client.facial_features
    db.dict_collection.insert({'id':photo_title, "details":face_details_imported})
    dict_imported_mongo=list(db.dict_collection.find({'id':photo_title}))[0]  #<-- 0 is eval and selects first of all duplicates.
    def extract_emotions(dict_mongo,photo):
        coords_x_m=[]
        coords_y_m=[]
        emotion_plot_v1_m=[]
        emotion_plot_v2_m=[]
        emotion_plot_v3_m=[]
        num_of_people_m=len(dict_mongo['details']['FaceDetails'])

        for i in range(num_of_people_m):
            coords_x_m.append((dict_mongo)['details']['FaceDetails'][i][ 'Landmarks'][3]['X'])
            coords_y_m.append((dict_mongo)['details']['FaceDetails'][i][ 'Landmarks'][3]['Y'])

            emotion_type_v1_m=(dict_mongo)['details']['FaceDetails'][i]['Emotions'][0]['Type']
            emotion_conf_v1_m=round((dict_mongo)['details']['FaceDetails'][i]['Emotions'][0]['Confidence'],2)
            emotion_v1_m=str(emotion_type_v1_m)+' '+str(emotion_conf_v1_m)+"%"
            emotion_plot_v1_m.append(emotion_v1_m)

            emotion_type_v2_m=(dict_mongo)['details']['FaceDetails'][i]['Emotions'][1]['Type']
            emotion_conf_v2_m=round(dict_mongo['details']['FaceDetails'][i]['Emotions'][1]['Confidence'],2)
            emotion_v2_m=str(emotion_type_v2_m)+' '+str(emotion_conf_v2_m)+"%"
            emotion_plot_v2_m.append(emotion_v2_m)
            #
            # emotion_type_v3_m=(dict_mongo)['details']['FaceDetails'][i]['Emotions'][2]['Type']
            # emotion_conf_v3_m=round(dict_mongo['details']['FaceDetails'][i]['Emotions'][2]['Confidence'],2)
            # emotion_v3_m=str(emotion_type_v3_m)+' '+str(emotion_conf_v3_m)+"%"
            # emotion_plot_v3_m.append(emotion_v3_m)


        im = np.array(Image.open(f'images/{photo}'), dtype=np.uint8)
        len2=(im.shape[0])
        width2=im.shape[1]
        print(len2,width2)
        plt.rcParams.update({'font.size': 12})

        # Create figure and axes Adjust size all kinds
        fig,ax = plt.subplots(1,figsize=(12,8))
        ax.set_yticks([])
        ax.set_xticks([])
        for i in range(num_of_people_m):
        # Create a Rectangle patch
            rect = patches.Rectangle((coords_x_m[i]*width2-width2,coords_y_m[i]*len2-len2*.06),50,50,linewidth=1,edgecolor='yellow',facecolor='none')
            # Add the patch to the Axes
            ax.add_patch(rect)
            plt.text(coords_x_m[i]*width2-width2*.03,coords_y_m[i]*len2-len2*.085, emotion_plot_v1_m[i],color='yellow')
            plt.text(coords_x_m[i]*width2-width2*.03,coords_y_m[i]*len2-len2*.070, emotion_plot_v2_m[i],color='cyan')
            for spine in plt.gca().spines.values():
                spine.set_visible(False)

        plt.margins()
            # plt.text(coords_x_m[i]*width2-width2*.03,coords_y_m[i]*len2-len2*.055, emotion_plot_v3_m[i],color='white')
        ax.imshow(im)
        # plt.show()
    extract_emotions(dict_imported_mongo,photo_title)
    client = MongoClient()
    db = client.facial_features
    db.collection_names()
    dict_all_people_emo=[]
    dict_emotion_values_list_test=list(db.dict_collection.find({'id':photo_title}))[0]

    for i in range(len(dict_emotion_values_list_test['details']['FaceDetails'])):
        dict_all_people_emo.append(dict_emotion_values_list_test['details']['FaceDetails'][i]['Emotions'])
    print(f'number of people: {len((dict_all_people_emo))}')
    dict_emotion_values_v2={'happy':0, 'sad':0, 'angry':.0, 'confused':0, 'surprised':0, 'calm':0, 'unknown':0,'disgusted':0}

    for j in (dict_all_people_emo):
        for i in range(len(j)):
            dict_emotion_values_v2[j[i]['Type'].lower()]+=j[i]['Confidence']
    # dict_emotion_values_v2['happy']=dict_emotion_values_v2['happy']*.2
    dict_emotion_values_v2.values()
    dict_emotion_values_list=np.array(list(dict_emotion_values_v2.values())).reshape(-1,1)
    pd.DataFrame(dict_emotion_values_list )

    #Scale the appened dictionary.
    scaler=MinMaxScaler()
    X_train_minmax = scaler.fit_transform(dict_emotion_values_list)
    # X_train_minmax=[1-i for i in X_train_minmax]  #DEL
    # print("Average Array for all emotions")
    # X_train_minmax

    import pickle
    with open('Lyrics_Folder/df_export_final_w2v_retro.pkl','rb') as picklefile:
        dataframe_dist_added=pickle.load(picklefile)

    def song_dist(dataframe_dist_added):
    #     song_cosine=scipy.spatial.distance.cosine(dict_emotion_values_list, dataframe_dist_added)
        song_cosine=scipy.spatial.distance.cosine(X_train_minmax, dataframe_dist_added)

        return song_cosine
    # scipy.spatial.distance.cosine(dict_emotion_values_list, dataframe_dist_added.dist_col[2323])


    def feature_dist(dataframe_dist_added):
    #     song_cosine=scipy.spatial.distance.cosine(dict_emotion_values_list, dataframe_dist_added)
        song_cosine=scipy.spatial.distance.cosine(X_train_minmax[0:3], dataframe_dist_added)

        return song_cosine

    #try fuzzy
    from fuzzywuzzy import fuzz
    from fuzzywuzzy import process
    list_of_artists=dict(dataframe_dist_added.artist_x.value_counts()).keys()
    artist_fuzzy=process.extractOne(artist, list_of_artists)

    dataframe_dist_added_v2=dataframe_dist_added[dataframe_dist_added.artist_x==artist_fuzzy[0]].copy()
    dataframe_dist_added_v2['word_vec_similarity']=dataframe_dist_added_v2.dist_col.apply(song_dist)
    dataframe_dist_added_v2['emotionmatrix_dist']=dataframe_dist_added_v2.emotionmatrix.apply(feature_dist)

    len(dataframe_dist_added_v2)
    final_playlist=dataframe_dist_added_v2.sort_values(by='word_vec_similarity')
    final_playlist2=final_playlist.sort_values(by='emotionmatrix_dist')
    return final_playlist2.head(10)



# logg_import('https://peopledotcom.files.wordpress.com/2017/11/harry-meghan-15.jpg?crop=0px%2C0px%2C2000px%2C1050px&resize=1200%2C630')
