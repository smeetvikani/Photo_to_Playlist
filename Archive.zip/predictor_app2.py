import flask
from flask import request

import pickle
import datetime
from chart import logg_import as logg_import
import matplotlib.pyplot as plt
import six
import base64
import random
from flask import Flask, make_response
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.dates import DateFormatter
plt.rcParams.update({'font.size': 25})
# Initialize the app

app = flask.Flask(__name__)




@app.route("/")
def hello():
    return """welcome"""


# Let's turn this into an API where you can post input data and get
# back output data after some calculations.

# If a user makes a POST request to http://127.0.0.1:5000/predict, and
# sends an X vector (to predict a class y_pred) with it as its data,
# we will use our trained LogisticRegression model to make a
# prediction and send back another JSON with the answer. You can use
# this to make interactive visualizations.

@app.route("/predict", methods=["POST", "GET"])
def predict():
    is_uploaded_file = False
    if (request.form):
        video_num = (request.form.get('video_num')) or 'https://i2.cdn.turner.com/money/dam/assets/150802202649-google-laura-palmaro-780x439.jpg'
        artist = (request.form.get('artist'))
        if request.files:
            is_uploaded_file = True
            video_num = request.files.get('image_file')
    else:
        video_num = 'https://i2.cdn.turner.com/money/dam/assets/150802202649-google-laura-palmaro-780x439.jpg'
        artist = 'drake'




    img = six.BytesIO()
    df3=logg_import(video_num,artist,is_uploaded_file)
    plt.savefig(img, format='jpeg')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    response= '<img style="width:100%"src="data:image/png;base64,{}"'.format(plot_url)

    uris=[i for i in df3.uri]


    return flask.render_template('predictor.html', response=response ,data_df3=df3.to_html(),uris=uris,artist=artist)

if __name__ == '__main__':
	app.run(debug=True,port=8001)


# For public web serving:
# app.run(host='0.0.0.0')
